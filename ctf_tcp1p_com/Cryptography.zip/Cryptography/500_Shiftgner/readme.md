Name: Shiftgner 
Points: 500 

Description:
**Author**: `Wrth`

Surely LFSR is safe enough to sign a message, right? 

Solution:
