Name: Spider Shambles 
Points: 500 

Description:
**Author**: `Kisanak`

A completely ordinary file scrambler without any purpose of existence or something idk. 

Solution:
