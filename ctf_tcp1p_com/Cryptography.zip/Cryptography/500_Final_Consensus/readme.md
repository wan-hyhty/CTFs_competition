Name: Final Consensus 
Points: 500 

Description:
**Author**: `Kisanak`

Alice and Bob are speaking in hex, but they seem to understand each other. Will they reach the final consensus? 

Solution:
