Name: One Pad Time 
Points: 500 

Description:
**Author**: `Wrth`

At the wrong place at the wrong time 

Solution:
