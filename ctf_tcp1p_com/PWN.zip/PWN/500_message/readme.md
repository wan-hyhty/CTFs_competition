Name: message 
Points: 500 

Description:
**Author**: `gawrgare`

What do you want to say to me? 

Solution:
