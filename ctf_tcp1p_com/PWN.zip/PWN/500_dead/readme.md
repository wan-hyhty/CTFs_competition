Name: 💀 
Points: 500 

Description:
**Author**: `hyffs`

![Let him cook](https://i.pinimg.com/originals/22/61/57/226157a62b9da0ab025d71f35e5574e4.jpg) 

Solution:
