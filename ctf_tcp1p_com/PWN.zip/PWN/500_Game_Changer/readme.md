Name: Game Changer 
Points: 500 

Description:
**Author**: `itoid`

Are you a Game Changer? 

Solution:
