Name: Bluffer Overflow 
Points: 419 

Description:
**Author**: `rennfurukawa`

Maybe it's your first time pwning? Can you overwrite the variable? 

Solution:
