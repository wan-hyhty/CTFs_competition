Name: Compromised 
Points: 500 

Description:
**Author**: `lunaroa`

An unknown individual gained unauthorized access to our old FTPS server. Moreover, the perpetrator somehow managed to acquire our private key beforehand. Could you determine the extent of information compromised by the perpetrator this time? 

Solution:
