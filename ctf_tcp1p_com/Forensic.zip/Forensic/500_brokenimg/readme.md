Name: brokenimg 
Points: 500 

Description:
**Author**: `botanbell`

why the picture like this 

Solution:
