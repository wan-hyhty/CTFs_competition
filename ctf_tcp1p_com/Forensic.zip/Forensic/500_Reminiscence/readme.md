Name: Reminiscence 
Points: 500 

Description:
**Author**: `lunaroa`

We've detected unusual network traffic within our network. Upon inspection, it turns out that a malicious actor gained access to one of our staff's credentials and logged into the server. Could you analyze what actually occurred? 

Solution:
