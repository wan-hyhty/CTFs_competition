Name: scrambled egg 
Points: 100 

Description:
**Author**: `zran`

I accidentally scrambled my egg yesterday while I was looking at a png. Can you help me unscramble my egg? 

Solution:
