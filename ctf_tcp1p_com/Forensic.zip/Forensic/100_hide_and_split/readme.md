Name: hide and split 
Points: 100 

Description:
**Author**: `underzero`

Explore this disk image file, maybe you can find something hidden in it. 

Solution:
