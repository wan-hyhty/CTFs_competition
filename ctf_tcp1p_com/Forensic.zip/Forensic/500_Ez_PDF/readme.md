Name: Ez PDF 
Points: 500 

Description:
**Author**: `daffainfo`

I just downloaded this PDF file from a strange site on the internet.... 

Solution:
