Name: Hacked 
Points: 275 

Description:
**Author**: `daffainfo`

I just deployed a website on Linux, but 5 minutes later, suddenly, someone hacked the server, and the attacker managed to gain root access. Can you investigate my server and answer some questions related to this hack?

Download Link: http://68.183.106.234:9999

Alternative Link: http://144.126.206.182:9999

Alternative Link 2: https://mega.nz/file/WrQyWSSQ#F1Hp8zz0_izaFpZUp9rB0WJcbLtSrP8v81MDnK_Vxpk 

Solution:
