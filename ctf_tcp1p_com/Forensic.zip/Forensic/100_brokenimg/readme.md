Name: brokenimg 
Points: 100 

Description:
**Author**: `botanbell`

why the picture like this 

Solution:
