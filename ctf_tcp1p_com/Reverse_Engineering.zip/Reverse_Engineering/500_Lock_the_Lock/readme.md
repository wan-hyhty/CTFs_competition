Name: Lock the Lock 
Points: 500 

Description:
**Author**: `Kisanak`

Unlock the Unlocked 

Solution:
