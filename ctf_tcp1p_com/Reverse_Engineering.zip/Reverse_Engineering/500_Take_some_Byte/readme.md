Name: Take some Byte 
Points: 500 

Description:
**Author**: `omegathrone`

I think some code is need some effort to read 

Solution:
