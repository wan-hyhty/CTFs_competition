Name: Subject Encallment 
Points: 100 

Description:
**Author**: `Kisanak`

If there's something strange. In your neighborhood. Who you gonna call? 

Solution:
