Name: IOP 
Points: 500 

Description:
**Author**: `aimardcr`

I need to hide a secret, so I modified [this](http://www.artpol-software.com/) project for archiving files. 
I haven't implemented extract feature though. Pretty sure the archive looks like a normal archive, or is it? 

Solution:
