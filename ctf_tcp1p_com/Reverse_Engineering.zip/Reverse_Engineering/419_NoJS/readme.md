Name: NoJS 
Points: 419 

Description:
**Author**: `aimardcr`

i never really liked js, so i made it an executable. 

Solution:
