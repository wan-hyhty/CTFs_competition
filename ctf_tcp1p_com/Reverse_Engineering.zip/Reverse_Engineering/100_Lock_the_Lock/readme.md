Name: Lock the Lock 
Points: 100 

Description:
**Author**: `Kisanak`

Unlock the Unlocked 

Solution:
