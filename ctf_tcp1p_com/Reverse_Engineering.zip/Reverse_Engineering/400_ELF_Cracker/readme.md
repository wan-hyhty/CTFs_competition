Name: ELF Cracker 
Points: 400 

Description:
**Author**: `hyffs`

Just learned about elf structure a while ago, i've created a simple packer elf binary. Could you break it? This is "not your typical crackme's chall". 

Solution:
