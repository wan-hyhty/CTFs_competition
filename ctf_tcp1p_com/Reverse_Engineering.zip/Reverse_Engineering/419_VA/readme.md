Name: VA 
Points: 419 

Description:
**Author**: `aimardcr`

static-analysis might be useless. 

Solution:
