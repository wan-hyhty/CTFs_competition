Name: Debug Me 
Points: 100 

Description:
**Author**: `aimardcr`

debug me and get the flag! 

Solution:
