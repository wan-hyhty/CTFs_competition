Name: OTA 
Points: 491 

Description:
**Author**: `aimardcr`

I just made this application that's capable of on-the-air update!\
I'm still using HTTP instead of HTTPS though...do you think it's safe?

The flag is located at `/data/data/intechfest.cc.ota/files/flag.txt`

**Guide**:\
You don't really need malicious application for this challenge, but you will need to create an exploit to solve this challenge.

Any submissions outside the intented solution will be considered as **INVALID**.\
For example, these types of solution is considered as invalid:
- Downloading the challenge APK from the remote connection
- Reading the file that contains the flag without using any exploits
- Breaking the device using any unintended exploits

**Note**:\
It might take some time for the instance to be fully initialized, please wait for approximately 5 minutes for the instance to be initialized.
If it's already 10 minutes and you can't use the connection, stop the instance and try again. 

Solution:
