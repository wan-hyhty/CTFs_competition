Name: Imagery 
Points: 436 

Description:
**Author**: `aimardcr`

Convert your image to Base64 string from your phone without any hassle!\
Pick your image, and you will be on your way!

The flag is located at `/data/data/com.kuro.imagery/files/flag.txt`

**Guide**:\
This challenge requires a malicious application. \
Make your own malicious/exploit application which you will be installing in the Virtual Android Device.

Any submissions outside the intented solution will be considered as **INVALID**.\
For example, these types of solution is considered as invalid:
- Downloading the challenge APK from the remote connection
- Reading the file that contains the flag without using any exploits
- Breaking the device using any unintended exploits

**Note**:\
It might take some time for the instance to be fully initialized, please wait for approximately 5 minutes for the instance to be initialized.
If it's already 10 minutes and you can't use the connection, stop the instance and try again. 

Solution:
