Name: VIP 
Points: 100 

Description:
**Author**: `Kiinzu`

A very simple system at a party.
If you are a VIP, you can get everything. 

Solution:
