Name: Invitation 
Points: 500 

Description:
**Author**: `Kiinzu`

An Invitation to an amazing party,
only if you find the right location.

**Note**: Please read the 101.txt. 

Solution:
