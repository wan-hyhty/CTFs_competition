Name: Location 
Points: 500 

Description:
**Author**: `Kiinzu`

Will you accept the invitation?
If so, find the party location now! 

Solution:
