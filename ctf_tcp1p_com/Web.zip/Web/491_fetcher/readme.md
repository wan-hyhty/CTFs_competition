Name: fetcher 
Points: 491 

Description:
**Author**: `Dimas`

As the name says, the website will fetch something... 

Solution:
