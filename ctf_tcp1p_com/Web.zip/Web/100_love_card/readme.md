Name: love card 
Points: 100 

Description:
**Author**: `kiseki`

Make your own love card for your gf <3 

Solution:
