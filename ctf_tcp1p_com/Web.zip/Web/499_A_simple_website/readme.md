Name: A simple website 
Points: 499 

Description:
**Author**: `daffainfo`

It turns out that learning to make websites using NuxtJS is really fun 

Solution:
