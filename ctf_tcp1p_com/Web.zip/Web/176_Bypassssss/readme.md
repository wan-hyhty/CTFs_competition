Name: Bypassssss 
Points: 176 

Description:
**Author**: `Daffainfo`

I used to have a website but unfortunately my website always gets hacked :(. But now I'm pretty sure they won't break into my website, right? right?!?! 

Solution:
