Name: PDFIFY 
Points: 484 

Description:
**Author**: `Dimas`

My friend told me that he wants to build a PDF generator for our assignment, so we created this app. Could you please test it for me? 

Solution:
