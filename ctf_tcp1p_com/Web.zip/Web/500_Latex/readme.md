Name: Latex 
Points: 500 

Description:
**Author**: `Dimas`

My first LaTeX website for my math teacher. I hope this will become the best gift for him! :) 

Solution:
