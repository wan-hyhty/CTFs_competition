Name: Calculator 
Points: 419 

Description:
**Author**: `Dimas`

For my college assignment, I was tasked with creating a unique calculator app, not your typical calculator application. Could you give it a try and test it for me? 😎 

Solution:
