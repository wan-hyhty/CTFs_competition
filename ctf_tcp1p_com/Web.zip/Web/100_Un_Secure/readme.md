Name: Un Secure 
Points: 100 

Description:
**Author**: `Dimas`

Do you know what "unserialize" means? In PHP, unserialize is something that can be very dangerous, you know? It can cause Remote Code Execution. And if it's combined with an autoloader like in Composer, it can use gadgets in the autoloaded folder to achieve Remote Code Execution. 

Solution:
