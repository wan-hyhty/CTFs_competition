Name: PyMagic 
Points: 499 

Description:
**Author**: `lunaroa`

Do you believe in PEP's magic?

Credits to `Wrth` & `yqroo` for evaluating the script 

Solution:
