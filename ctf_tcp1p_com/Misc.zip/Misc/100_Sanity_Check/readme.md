Name: Sanity Check 
Points: 100 

Description:
**Author**: `Hackerika`

Don't forget to join our discord at https://discord.com/invite/Gj6h9TjN3D 

Solution:
