Name: Nuclei 
Points: 244 

Description:
**Author**: `daffainfo`

Nuclei is a fast, template based vulnerability scanner focusing on extensive configurability, massive extensibility and ease of use. 

Solution:
