Name: Guess My Number 
Points: 100 

Description:
**Author**: `rennfurukawa`

My friend said if i can *guess* the right number, he will give me something.
Can you help me? 

Solution:
