Name: Certificate 
Points: 1 

Description:
**Author**: `.secre`

Don't forget to claim your certificate right here
and proudly share your achievement on your social media platforms
using the hashtags #TCP1P and #TCP1PCTF2023.
We appreciate your participation in this CTF,
and we thank each and every one of you for joining this event! 

Solution:
