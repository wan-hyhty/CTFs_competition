Name: vampire 
Points: 484 

Description:
**Author**: `botanbell`

please give it a try, it seems like it has been done before 

Solution:
