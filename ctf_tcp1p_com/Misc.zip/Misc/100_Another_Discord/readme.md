Name: Another Discord 
Points: 100 

Description:
**Author**: `daffainfo`

TCP1P has another discord server? 

Solution:
