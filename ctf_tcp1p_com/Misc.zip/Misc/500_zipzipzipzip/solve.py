import zipfile

def extract_zip_with_password(zip_file, password_file):
    with open(password_file, 'r') as f:
        password = f.read().strip()  # Đọc mật khẩu từ tệp tin password.txt

    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        try:
            zip_ref.extractall(pwd=password.encode())  # Giải nén với mật khẩu
            print("Đã giải nén thành công.")
        except RuntimeError:
            print("Mật khẩu không đúng.")

# Sử dụng hàm để giải nén tệp tin zip
for i in range(24999, 0, -1):
    extract_zip_with_password(f'zip-{i}.zip', 'password.txt')