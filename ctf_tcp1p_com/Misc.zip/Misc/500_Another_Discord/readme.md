Name: Another Discord 
Points: 500 

Description:
**Author**: `daffainfo`

TCP1P has another discord server? 

Solution:
