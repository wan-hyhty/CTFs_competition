# Tiny-WebServer

## Usage
**Compile**
```
make
chmod +x tiny
chmod +x cgi-bin/adder
```
**Run server**
```
./tiny 8000
```
**Open the browser**

static page http://localhost:8000

dynamic page http://localhost:8000/cgi-bin/adder?1&2

