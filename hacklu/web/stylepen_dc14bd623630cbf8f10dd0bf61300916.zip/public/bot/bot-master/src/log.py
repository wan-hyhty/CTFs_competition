def log(tag, *msg):
    print(tag, *msg)
