Redis.sadd_returns_boolean = false
