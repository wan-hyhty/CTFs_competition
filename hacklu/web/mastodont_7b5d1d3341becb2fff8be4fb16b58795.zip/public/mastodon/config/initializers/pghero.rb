PgHero.show_migrations = Rails.env.development?
