# frozen_string_literal: true

StrongMigrations.start_after = 20170924022025
