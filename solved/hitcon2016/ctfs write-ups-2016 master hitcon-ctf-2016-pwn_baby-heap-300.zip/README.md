# HITCON CTF 2016 : baby-heap-300

**Category:** pwn
**Points:** 300
**Solves:**
**Description:**

> Heap so fun! Baby, don't do it first. nc 52.68.77.85 8731   note : the service is running on ubuntu 16.04


## Write-up

(TODO)

## Other write-ups and resources

* [Shift Crops (Japanese)](http://shift-crops.hatenablog.com/entry/2016/10/11/233559#Babyheap-Pwn-300
