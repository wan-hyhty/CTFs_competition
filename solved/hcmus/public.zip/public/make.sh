#!/bin/bash
docker run -p 1337:1337 --cpus="1.0" --rm -it m3k4/introduction
