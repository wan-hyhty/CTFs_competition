<?php

namespace Exception;

use RuntimeException;

class NotFoundException extends RuntimeException
{
}