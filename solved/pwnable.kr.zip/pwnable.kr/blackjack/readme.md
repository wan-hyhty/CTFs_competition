# blackjack
## Phân tích
- một bài bof 
- Ta sẽ bet với số âm và thua thì `cash = cash - bet`, cash lớn hơn 1 triệu

```
YaY_I_AM_A_MILLIONARE_LOL


Cash: $1000000500
-------
|D    |
|  4  |
|    D|
-------

Your Total is 4

The Dealer Has a Total of 9

Enter Bet: $

```
