# cmd1
```./cmd1 "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin cat 'f'lag"```
```mommy now I get what PATH environment is for :)```