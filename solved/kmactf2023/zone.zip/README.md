Nên build lại để có debug symbol
Build:
cmake ./
make

P/s: Offset có thể có 1 chút thay đổi giữa docker và binary được patched với pwninit