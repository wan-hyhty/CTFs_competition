# libZONE
Author: peternguyen

This library was created for learning purpose, libzone is implemented BSD/XNU kernel zone allocator in user-space

# Compiling
```bash
mkdir buid
cd build
cmake ../
ninja
```
