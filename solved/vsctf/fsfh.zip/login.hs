{-# LANGUAGE OverloadedStrings #-}
import Control.Monad
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import qualified Data.ByteString.Char8 as BSC
import Data.Word
import Foreign.Marshal.Alloc
import Foreign.Marshal.Array
import Foreign.Ptr
import Foreign.Storable
import System.Exit (exitFailure)
import System.IO.Error (catchIOError, isDoesNotExistError)
import System.IO.Unsafe
import System.IO (hSetBuffering, BufferMode(..), stdout)
import System.Process (callCommand)

loadPassword :: FilePath -> IO (Either String ByteString)
loadPassword filePath = catchIOError load handler
  where
    load = Right <$> BS.readFile filePath
    handler e | isDoesNotExistError e = return (Left $ "Error: " ++ filePath ++ " not found!")
              | otherwise = return (Left $ "An error occurred while reading " ++ filePath)

-- Thank you UPenn https://www.seas.upenn.edu/~cis1940/spring15/lectures/12-unsafe.html --
checkPwd :: ByteString -> ByteString -> IO Bool
checkPwd s1 s2
  | BS.length s1 > 32 || BS.length s2 > 32 = return False
  | otherwise = allocaArray 32 $ \b1 -> do
      let l1 = BS.length s1
          l2 = BS.length s2
          b2 = plusPtr b1 16
      pokeArray b2 (BS.unpack s2)
      when (l2 < 16) $ pokeArray (plusPtr b2 l2) (replicate (16 - l2) (0 :: Word8))
      pokeArray b1 (BS.unpack s1)
      when (l1 < 16) $ pokeArray (plusPtr b1 l1) (replicate (16 - l1) (0 :: Word8))
      and <$> forM [0..15] (\i -> do
        c1 <- peekByteOff b1 i :: IO Word8
        c2 <- peekByteOff b2 i
        return $ c1 == c2)

login :: IO ()
login = do
    putStr "Password: "
    guess <- BS.getLine
    result <- loadPassword "password.txt"
    case result of
        Left err -> putStrLn err
        Right password -> do
            match <- checkPwd guess password
            if match then do
                putStrLn "You are logged in!"
                callCommand "runhaskell fileserver.hs"
            else do
                putStrLn "Incorrect password"
                exitFailure

main :: IO ()
main = login
