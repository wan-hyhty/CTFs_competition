#!/bin/bash

cd /home/user

exec 2>/dev/null
timeout 30 /home/user/prob
