#!/bin/bash
/ctf/robber /ctf/chall