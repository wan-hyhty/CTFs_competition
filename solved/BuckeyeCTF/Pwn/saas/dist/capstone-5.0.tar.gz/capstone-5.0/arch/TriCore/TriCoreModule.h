//
// Created by aya on 3/4/23.
//

#ifndef CAPSTONE_TRICODEMODULE_H
#define CAPSTONE_TRICODEMODULE_H

cs_err TRICORE_global_init(cs_struct *ud);
cs_err TRICORE_option(cs_struct *handle, cs_opt_type type, size_t value);

#endif // CAPSTONE_TRICODEMODULE_H
