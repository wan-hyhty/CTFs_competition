Name: Time chaos Revenge 
Points: 856 

Description:
Time chaos của KMACTF lần 1 đã quay trở lại. Không còn dễ như lần trước nữa đâu mặc dù lần này có thêm source

[Download](https://drive.google.com/file/d/1nNJtBDSB4kX1q7lvuq2cB_is7FpCQCu4/view?usp=drive_link)

Flag format: `KMACTF{}`

Author: bquanman 

Solution:
