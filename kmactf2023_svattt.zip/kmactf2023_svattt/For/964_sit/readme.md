Name: sit 
Points: 964 

Description:
When I have started my computer, my secret document is encrypted. I think I am a victim of a targeted attack

[Download](https://drive.google.com/file/d/1IsUmTXV76tuO5u3CZa2Lx8cTg-6h0sN5/view?usp=drive_link)

Password: `2w#_4w|e{Jh<2)};3by<{>}G3$h;2vuF3>'D4Jga|s|a}`

Flag format: `KMACTF{}`

Author: bquanman 

Solution:
