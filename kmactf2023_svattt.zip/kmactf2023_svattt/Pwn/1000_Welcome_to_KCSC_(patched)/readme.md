Name: Welcome to KCSC (patched) 
Points: 1000 

Description:
OMG! The website was vulnerable to a critical bug so I managed to patch it immediately. Then I implemented a back-end service to manage the front-end. I bet you can attack it if you can 😏

> Install dependency `Flask` with pip3 then run `python3 run.py`

http://103.162.14.116:5002/ 

Solution:
