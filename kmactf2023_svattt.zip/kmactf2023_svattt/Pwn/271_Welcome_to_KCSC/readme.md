Name: Welcome to KCSC 
Points: 271 

Description:
I created a website for my club and I bet you can get the root flag which is at "/root/root.txt" . Don't let me down with your skill!!!

> Install dependency `Flask` with pip3 then run `python3 run.py`

http://103.162.14.116:5001/ 

Solution:
