Name: Tiny-Webserver 
Points: 1000 

Description:
http://103.162.14.116:4096/

#flag in /home/flag.txt

Exploit on your local first, do not dos attack 

Solution:
