Name: ez-ssti 
Points: 1000 

Description:
Have you ever heard about Thymeleaf SSTI?

http://103.162.14.116:40050 

Solution:
