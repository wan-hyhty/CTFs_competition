Name: baby python 
Points: 991 

Description:
P/s: thử local trước xong hãy gửi payload lên server bạn nhes~!

**Create challenge**: https://gist.github.com/hypnguyen1209/9ee2c1b38c807e86ab3b9045d3a4edca 

Solution:
