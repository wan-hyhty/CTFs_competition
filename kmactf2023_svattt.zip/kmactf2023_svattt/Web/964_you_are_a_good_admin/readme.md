Name: you are a good admin 
Points: 964 

Description:
<img src="/files/62666648bcae8a1a0d3d0807b2cdf26b/anya_so_cute.png" alt="anya" width="500"/>

P/s: thử local trước xong hãy gửi payload lên server bạn nhes~!

**Create challenge**: https://gist.github.com/hypnguyen1209/9ee2c1b38c807e86ab3b9045d3a4edca 

Solution:
