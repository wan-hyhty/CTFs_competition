Name: Tiệm bánh dâu tây 
Points: 1000 

Description:
Ngày đông hương thơm đường vắng<br>
Mùi bánh kem sữa dâu tây<br>
Nhìn xuyên qua ô cửa kính<br>
Ai với chiếc bánh kem dâu hồng<br><br>
http://103.162.14.116:8888/

**author: null001** 

Solution:
