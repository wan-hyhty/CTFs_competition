Name: Puzzle 
Points: 559 

Description:
 

Solution:
