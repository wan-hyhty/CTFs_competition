Name: Discord check 
Points: 10 

Description:
 

Solution:
