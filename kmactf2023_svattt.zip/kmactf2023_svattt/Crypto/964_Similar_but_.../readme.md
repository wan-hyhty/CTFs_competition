Name: Similar but ... 
Points: 964 

Description:
Quen quen ... 

Solution:
