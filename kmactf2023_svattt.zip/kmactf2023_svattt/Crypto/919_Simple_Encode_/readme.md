Name: Simple Encode  
Points: 919 

Description:
Thưa các quý ngài đơn giản 

Solution:
