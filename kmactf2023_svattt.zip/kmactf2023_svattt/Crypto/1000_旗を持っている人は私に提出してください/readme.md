Name: 旗を持っている人は私に提出してください 
Points: 1000 

Description:
```
chmod 600 recover_key.pem
ssh -p 2222 -i recover_key.pem sena@103.162.14.116
cat /flag.txt
5 qua trung or 1 ten lua ?
``` 

Solution:
