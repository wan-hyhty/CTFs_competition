Name: Bazoka 
Points: 919 

Description:
Bang Bang Bang !!! 

Solution:
