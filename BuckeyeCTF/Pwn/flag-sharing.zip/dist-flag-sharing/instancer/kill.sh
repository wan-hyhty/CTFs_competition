#!/bin/bash
docker kill $1