Name: welcome 
Points: 10 

Description:
8Q/2[6r[05G@bT,@o$rQ?Z[u/8Q0>FA9;s$@ru=2 

Solution:
