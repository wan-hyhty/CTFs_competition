Name: Ransomware 
Points: 100 

Description:
My computer is infected with ransomware :(, I got memory dump, not sure if that can help you?</br>
Can you answer the following questions?</br>
- When does malicious code appear on the computer? (format yyyy-mm-dd_hh-mm-ss in UTC+7)</br>
- What is the name of the persistence mechanism?</br>
- What name did the infection originate from?

<a href="https://drive.google.com/file/d/1Bl_Tn6ICdUi9Ug5XV74SMFB2iefY4nnk/view?usp=sharing">Link download</a></br>
`format flag: ISITDTU{time_persistencename_originalname}` 

Solution:
