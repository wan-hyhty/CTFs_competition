Name: Discover 
Points: 150 

Description:
During her trip to China, Cithrel Wynhice posted a flycam-captured photo on her social media and challenged her fans to locate the exact spot in the picture and tell her the name of the tall building across from it.</br>
`Format flag: ISITDTU{danang_azura_apartment}`</br>
`author: vizer` 

Solution:
