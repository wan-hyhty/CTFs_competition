Name: traffic 
Points: 100 

Description:
I found a strange process on my computer trying to connect to the internet, can you tell me what it sends?</br>
`format flag: ISITDTU{flag}` 

Solution:
