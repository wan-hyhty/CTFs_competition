Name: Steg Crack 
Points: 295 

Description:
Can you find the flag? 

Solution:
