Name: Famous girl 
Points: 100 

Description:
Cithrel Wynhice, a captivating social media influencer known for her beauty and wanderlust, had embarked on a journey to explore the enchanting landscapes of China. Her followers eagerly awaited her posts, hungry for the next breathtaking photo or exciting adventure. However, what started as a picturesque exploration soon turned into an unexpected mystery.
<br><br>
Format flag: ISITDTU{f4k3_fL49}
<br><br>
*Author: Vizer* 

Solution:
