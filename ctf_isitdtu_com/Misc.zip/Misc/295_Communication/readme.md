Name: Communication 
Points: 295 

Description:
It seems like Cithrel Wynhice wants to have a place to socialize with her fans.</br>
`Format flag: ISITDTU{f4k3_fL49}`</br>
`author: vizer` 

Solution:
