Name: vibanxungdang 
Points: 496 

Description:
The use of brute force scanning is strictly prohibited; it's all in the source code.</br>
http://20.198.223.134:1337 </br>
`Author: Discord _onsra_` 

Solution:
