Name: EzPHP 
Points: 500 

Description:
Link: http://34.142.236.192:8091 

Solution:
