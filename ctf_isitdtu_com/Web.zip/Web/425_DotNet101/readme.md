Name: DotNet101 
Points: 425 

Description:
This is the default page aspx 🐍 <br>
Link: http://40.88.10.36/
<br><br>
[Source Code](https://drive.google.com/drive/folders/1FtITddB1GFUzq7wBLvxh3_G6xckMub_n?usp=sharing)
<br><br>
*Author: taidh* 

Solution:
