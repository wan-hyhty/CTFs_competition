Name: thru the filter 
Points: 100 

Description:
SSTI starting point</br>
Link: http://34.124.244.195:1338/

`author: Khanhhnahk1` 

Solution:
