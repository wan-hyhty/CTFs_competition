Name: Flag Keeper 
Points: 496 

Description:
Seek Gerry, He knows where (graveyard/reverse) and how (dig/decrypt) to get the Flag.

`author: ks75vl` 

Solution:
