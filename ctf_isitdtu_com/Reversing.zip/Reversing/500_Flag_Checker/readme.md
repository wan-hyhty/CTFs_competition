Name: Flag Checker 
Points: 500 

Description:
Breaking News: "FlagChecker, The Ultimate Flag Verification Tool, Leaked!!!"</br>
<a href="https://drive.google.com/file/d/1StR48M03IuhDaOupAoPNAuwEJMTPsHs9/view?usp=sharing">Download</a></br>
`author: ks75vl` 

Solution:
