Name: Dot 
Points: 127 

Description:
What do you think if you start by warming up with oldschool?</br>

`format flag: ISITDTU{flag}` 

Solution:
