Name: simple_encrypt 
Points: 413 

Description:
How many types of encryption algorithms do you know?</br>
<a href="https://mega.nz/file/PqJBmJTD#CJxiJfEXRDbfGV78MqXkjl5qtnHv2CpszHAyENX9y7M">Download</a>

`format flag: ISITDTU{flag_is_here}` 

Solution:
