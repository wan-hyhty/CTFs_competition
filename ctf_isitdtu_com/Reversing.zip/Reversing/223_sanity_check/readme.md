Name: sanity_check 
Points: 223 

Description:
Simple challenge to ensure our system works normally ;) 

Solution:
