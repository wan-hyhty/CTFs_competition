Name: Forensics 03 
Points: 282 

Description:
**3.What technique did the hacker use to maintain a connection with the system?** 

Solution:
