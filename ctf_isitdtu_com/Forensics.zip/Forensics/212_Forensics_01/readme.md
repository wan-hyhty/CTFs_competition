Name: Forensics 01 
Points: 212 

Description:
I recreated a simulation where a hacker attacked a server Exhange
I have collected the necessary logs and some suspicious processes to support the investigation process. Use your DFIR skills to answer the following questions: </br>
**1.Which service on the server did the hacker exploit?**</br><br>
This source is used for all challenges in this category: <a href="https://drive.google.com/file/d/129yVERsAZlVQBSpEQYuQcJ1_TBJTGTFT/view?usp=sharing">Download </a></br>
`format flag: ISITDTU{answer}` </br>
`author: ego` 

Solution:
