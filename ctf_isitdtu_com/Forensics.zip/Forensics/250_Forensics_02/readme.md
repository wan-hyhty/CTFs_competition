Name: Forensics 02 
Points: 250 

Description:
**2.What is the CVE identifier for the vulnerability that the hacker used?** 

Solution:
