Name: Forensics 05 
Points: 292 

Description:
**5. Can you find the hidden secret with the key to open it?Ex:secret_key** 

Solution:
