Name: Forensics 04 
Points: 286 

Description:
**4.What is the malicious "file" that the hacker left behind?** 

Solution:
