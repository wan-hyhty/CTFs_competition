Name: d_low 
Points: 489 

Description:
`author: manrop` 

Solution:
