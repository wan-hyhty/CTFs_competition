Name: homemade primes 
Points: 500 

Description:
 

Solution:
