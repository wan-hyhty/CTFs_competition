Name: homemade primes 
Points: 464 

Description:
 

Solution:
