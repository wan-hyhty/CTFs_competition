Name: MagicPrime 
Points: 496 

Description:
Looking for the flag? You'll definitely need to whip up a magical Prime, and don't forget to use my special magic salt!</br>
Link1: nc 34.143.210.103 5001</br>
Link2: nc 34.124.255.88 5001</br>

`Author: trnam11` 

Solution:
