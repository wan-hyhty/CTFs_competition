Name: MemeStorage 
Points: 464 

Description:
Welcome to my Meme Storage. It contains a selection of dark memes, hence, access is exclusively reserved for administrators.</br>
nc 34.143.249.126 5002 </br>
`Author: trnam11` 

Solution:
